
public class Trap extends GameEntity{
	public Trap(){
		super();
		this.isLocated=false;
	}
	public String getType() {
		return "Trap";
		
	}

}
