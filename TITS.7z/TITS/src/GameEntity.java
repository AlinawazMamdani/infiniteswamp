import java.util.ArrayList;
import java.util.Random;
//game entities encompass all objects that can exist on the board
//does a board need to exist, 
//need a function to generate a random position on the board
//extra functionality other game entities would be easiest to implement simply abstracting of the game entity class
//an entity could also be a trap, implementing 3 traps means that the game is still able to be completed without any trap logic without any extra code 
//
abstract public class GameEntity {
	protected boolean isLocated;
	private int possibleX= 10;
	private int possibleY= 10;
	private int xPosition;
	private int yPosition;
	private int[] currentPos= {0,0};
	private static ArrayList<int[]> usedEntityLocations= new ArrayList<int[]>();
	private static ArrayList<GameEntity> gameEntityList= new ArrayList<GameEntity>();
	public int getxPosition() {
		return this.xPosition;
		
	}
	public int getYposition() {
		return this.yPosition;
	}
	public ArrayList<GameEntity> gameEntityList(){
		return gameEntityList;
	}
	public GameEntity(){
		this.currentPos=randomPosition();
	
		gameEntityList.add(this);
		printBoard();
		}
	public int[] randomPosition() {
	int potentialX=(int) (Math.round(Math.random()*10));
	int potentialY=(int) (Math.round(Math.random()*10));
	
		this.xPosition=potentialX;
		this.yPosition=potentialY;
		this.currentPos[0]=this.xPosition;
		this.currentPos[1]=this.yPosition;
		return this.currentPos;
		
		
	}
	public void movePosition(String Posmovement){
		switch(Posmovement.toLowerCase()) {
		case("s"):
			if (yPosition==possibleY) {
				this.yPosition=0;
			}else {this.yPosition+=1;
			}
		break;
		case("d"):
			if (xPosition==possibleX) {
				this.xPosition=0;
			}else {this.xPosition+=1;
			}
		break;
		case("a"):
			if (this.xPosition==0) {
				this.xPosition=possibleX;
			}else {
				this.xPosition-=1;
		}
		break;
		case("w"):
			if (this.yPosition==0) {
				this.yPosition=possibleY;
			}else {
				this.yPosition-=1;
			}
		}
		//entityLocations.remove(entityLocations.size()-1);
		//int[] newEntityLoc= {this.xPosition,this.yPosition};
		//entityLocations.add(newEntityLoc);	
		printBoard();
	}
	public int[] getPosition(){
		int[] currentPos={this.xPosition,this.yPosition};
		return currentPos;
	}
	abstract String getType();
public static double entityDistance(GameEntity a,GameEntity b) {
	double distance =0;
	int xDistance=a.xPosition-b.xPosition;
	int yDistance=a.yPosition-b.yPosition;
	if (xDistance<0) {
		xDistance = xDistance*(-1);
	}
	if (yDistance<0) {
		yDistance=yDistance*(-1);
	}
	distance = Math.pow(Math.pow(xDistance, 2)+Math.pow(yDistance,2),0.5);
	return distance;
}
private void printBoard() {
	boolean lastEntity=false;
	for(int i=0;i<possibleY+1;i++) {
		for (int j=0;j<possibleX+1;j++) {
			for (GameEntity k:gameEntityList) {
				if (k.xPosition==j && k.yPosition==i && k.isLocated==true) {
					System.out.print(" 0 ");
					lastEntity=true;
				}
				}
			if (lastEntity==false) {
				System.out.print(" - ");
			}
			lastEntity=false;
			}
		System.out.println("");
		}	
	}
public static void endGame() {
	gameEntityList.clear();
}
}
