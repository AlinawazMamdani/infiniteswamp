
public class Player extends GameEntity{
	private String name;
	
	
	public Player(String name) {
		
		super();
		isLocated=true;
		this.name=name;
		
	}
	public Player() {
		super();
		isLocated=true;
		this.name="Bob";
	}
	public String getType() {
		return "Player";
		
	}
	public String getName() {
		return this.name;
		
	}
}
