
public class Treasure extends GameEntity{
	
	public Treasure(){
		super();
		this.isLocated=false;
		
	}
	public String getType() {
		return "Treasure";
	}
}
