import java.util.Scanner;

public class app {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);

	boolean play=true;
	while (play==true){
		boolean win = false;
		int turns=0;
		System.out.println("Welcome to the infinite tessellating swamp where you or bob set out to find the treasure to help get you out");
		Player newPlayer;
		Treasure newTreasure=new Treasure();
		System.out.println("Enter a name or none for no name");
		String name=s.nextLine();
		if (name.length()>0) {
			 newPlayer=new Player(name);
		}else {
		newPlayer=new Player();
		}
	
		while (win==false) {
			if (newPlayer.getPosition()[0]==newTreasure.getPosition()[0] && newPlayer.getPosition()[1]==newTreasure.getPosition()[1]&& turns>0) {
				break;
			}else if((newPlayer.getPosition()[0]==newTreasure.getPosition()[0] && newPlayer.getPosition()[1]==newTreasure.getPosition()[1]&& turns==0)){
				newPlayer.randomPosition();
			}
			System.out.println("Your current position x=" + newPlayer.getPosition()[0]+ " y="+newPlayer.getPosition()[1]);
			System.out.println("What direction would you like to move W for North A for east S for south D for west");
			newPlayer.movePosition(s.nextLine());
			System.out.println("Your compass says you are "+GameEntity.entityDistance(newPlayer, newTreasure)+" spaces away from the treasure");
			turns=turns+1;
		}
		System.out.println("Congratulations "+newPlayer.getName()+" found the treasure in " + turns+ " turns would you like to play again? Y for YES! n for no");
		GameEntity.endGame();
		if (s.nextLine().equals("n")) {
			play=false;
		}
	}
}


}
